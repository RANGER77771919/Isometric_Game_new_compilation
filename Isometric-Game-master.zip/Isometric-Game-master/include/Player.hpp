#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <string>

// Declaración anticipada de World para evitar dependencia circular
class World;

/**
 * @class Player
 * @brief Representa al jugador en el mundo isométrico 3D
 *
 * El jugador tiene una posición en coordenadas mundiales (x, y, z) donde:
 * - X: Coordenada horizontal este-oeste
 * - Y: Coordenada vertical (altura)
 * - Z: Coordenada horizontal norte-sur
 *
 * El jugador puede moverse, spawnear en la superficie del terreno y ser
 * renderizado usando un tile específico.
 */
class Player {
public:
    /**
     * @brief Constructor del jugador
     * @param x Coordenada X inicial (posición horizontal este-oeste)
     * @param y Coordenada Y inicial (altura/vertical)
     * @param z Coordenada Z inicial (posición horizontal norte-sur)
     *
     * Inicializa el jugador en la posición especificada del mundo.
     * Generalmente se crea en (0, 0, 0) y luego se reubica con spawnOnSurface().
     */
    Player(float x, float y, float z);

    /**
     * @brief Destructor por defecto
     *
     * No necesita liberar recursos adicionales ya que solo almacena
     * coordenadas flotantes básicas.
     */
    ~Player() = default;

    /**
     * @brief Obtiene la posición actual del jugador
     * @param x Variable de salida para la coordenada X
     * @param y Variable de salida para la coordenada Y (altura)
     * @param z Variable de salida para la coordenada Z
     *
     * Las coordenadas se pasan por referencia para ser modificadas.
     * Útil para obtener la posición actual del jugador para renderizado,
     * detección de colisiones, o actualización de la cámara.
     */
    void getPosition(float& x, float& y, float& z) const;

    /**
     * @brief Establece la posición del jugador
     * @param x Nueva coordenada X (posición horizontal este-oeste)
     * @param y Nueva coordenada Y (altura/vertical)
     * @param z Nueva coordenada Z (posición horizontal norte-sur)
     *
     * Teletransporta al jugador a la posición especificada.
     * Útil para reposicionar al jugador después de cargar un chunks,
     * respawn, o efectos de teletransporte.
     */
    void setPosition(float x, float y, float z);

    /**
     * @brief Muve al jugador relativamente desde su posición actual
     * @param dx Delta de movimiento en el eje X (positivo = este, negativo = oeste)
     * @param dy Delta de movimiento en el eje Y (positivo = arriba, negativo = abajo)
     * @param dz Delta de movimiento en el eje Z (positivo = sur, negativo = norte)
     *
     * Los deltas se suman a la posición actual. Se usa durante el manejo
     * de input del jugador para movimiento continuo basado en deltaTime.
     * Los valores típicos son pequeños (ej: 0.1 por frame).
     */
    void move(float dx, float dy, float dz);

    /**
     * @brief Spawnea al jugador en la superficie del terreno
     * @param world Puntero al mundo donde buscará la superficie
     *
     * Este método busca el bloque sólido más alto en la posición (X, Z) del jugador
     * y lo coloca sobre ese bloque (Y = superficie + 1).
     *
     * Algoritmo:
     * 1. Obtiene el chunk en la posición actual del jugador
     * 2. Si el chunk no existe, lo genera
     * 3. Busca desde arriba (Y=255) hacia abajo el primer bloque sólido
     * 4. Posiciona al jugador una unidad sobre ese bloque
     *
     * Esto asegura que el jugador siempre aparezca sobre el terreno
     * y no dentro de la tierra o flotando en el aire.
     */
    void spawnOnSurface(World* world);

    /**
     * @brief Obtiene el nombre del tile usado para renderizar al jugador
     * @return Cadena con el nombre de la textura ("player")
     *
     * El renderer usa este nombre para buscar la textura correspondiente
     * en el TextureManager. La textura debe estar cargada en assets/tiles/player.png
     */
    const char* getTileName() const { return "player"; }

private:
    float m_posX; ///< Coordenada X del jugador (posición horizontal este-oeste)
    float m_posY; ///< Coordenada Y del jugador (altura/vertical, 0 = fondo del mundo)
    float m_posZ; ///< Coordenada Z del jugador (posición horizontal norte-sur)
};

#endif // PLAYER_HPP
