/**
 * @file Player.cpp
 * @brief Implementación de la clase Player
 *
 * Este archivo contiene la implementación de los métodos de la clase Player,
 * que representa al jugador en el mundo isométrico 3D.
 */

#include "Player.hpp"
#include "World.hpp"
#include "Block.hpp"
#include <iostream>

/**
 * @brief Constructor del jugador
 * @param x Coordenada X inicial (posición horizontal este-oeste)
 * @param y Coordenada Y inicial (altura/vertical)
 * @param z Coordenada Z inicial (posición horizontal norte-sur)
 *
 * Inicializa las coordenadas del jugador con los valores proporcionados.
 * Imprime un mensaje de debug con la posición inicial.
 */
Player::Player(float x, float y, float z)
    : m_posX(x)
    , m_posY(y)
    , m_posZ(z)
{
}

/**
 * @brief Obtiene la posición actual del jugador
 * @param x Variable de salida para la coordenada X
 * @param y Variable de salida para la coordenada Y (altura)
 * @param z Variable de salida para la coordenada Z
 *
 * Las coordenadas se pasan por referencia y son modificadas con los valores actuales.
 * El método es const ya que no modifica el estado del jugador.
 */
void Player::getPosition(float& x, float& y, float& z) const {
    x = m_posX;
    y = m_posY;
    z = m_posZ;
}

/**
 * @brief Establece la posición del jugador
 * @param x Nueva coordenada X (posición horizontal este-oeste)
 * @param y Nueva coordenada Y (altura/vertical)
 * @param z Nueva coordenada Z (posición horizontal norte-sur)
 *
 * Teletransporta al jugador a la posición especificada.
 * Útil para respawn inicial, teletransporte, o correcciones de posición.
 */
void Player::setPosition(float x, float y, float z) {
    m_posX = x;
    m_posY = y;
    m_posZ = z;
}

/**
 * @brief Mueve al jugador relativamente
 * @param dx Delta de movimiento en el eje X (positivo = este, negativo = oeste)
 * @param dy Delta de movimiento en el eje Y (positivo = arriba, negativo = abajo)
 * @param dz Delta de movimiento en el eje Z (positivo = sur, negativo = norte)
 *
 * Los deltas se suman a la posición actual.
 * Se usa durante el game loop para movimiento continuo basado en input del jugador.
 * Los valores típicos son pequeños (ej: 0.1 * deltaTime por frame).
 */
void Player::move(float dx, float dy, float dz) {
    m_posX += dx;
    m_posY += dy;
    m_posZ += dz;
}

/**
 * @brief Spawnea al jugador en la superficie del terreno
 * @param world Puntero al mundo donde se buscará la superficie
 *
 * Este método implementa el algoritmo para encontrar la superficie del terreno:
 *
 * 1. Validación: Verifica que el puntero al mundo no sea nulo
 * 2. Obtener chunk: Convierte la posición del jugador a coordenadas de chunk
 * 3. Generar si es necesario: Si el chunk no existe, lo genera
 * 4. Calcular coordenadas locales: Convierte coordenadas mundiales a locales del chunk
 * 5. Buscar superficie: Recorre desde Y=255 hacia abajo buscando el primer bloque sólido
 * 6. Posicionar jugador: Coloca al jugador en Y = superficie + 1 (encima del bloque)
 *
 * El algoritmo de búsqueda de superficie:
 * - Comienza desde el tope del mundo (Y=255)
 * - Recorre hacia abajo (Y decrementando)
 * - El primer bloque donde esSolido() es true es la superficie
 * - El jugador se coloca una unidad arriba de ese bloque
 *
 * Esto asegura que el jugador siempre aparezca sobre el terreno y no
 * dentro de bloques sólidos o flotando en el aire.
 */
void Player::spawnOnSurface(World* world) {
    // Validar que el puntero al mundo no sea nulo
    if (!world) {
        std::cerr << "Error: Mundo es nulo en spawnOnSurface" << std::endl;
        return;
    }

    // Convertir la posición del jugador a coordenadas de bloque
    // Nota: La coordenada Y se establece en 0 ya que nos interesa la columna (X, Z)
    BlockPos blockPos(static_cast<int>(m_posX), 0, static_cast<int>(m_posZ));
    ChunkPos chunkPos = blockPos.toChunkPos();

    // Obtener el chunk en la posición del jugador
    const Chunk* chunk = world->getChunk(chunkPos);

    // Si el chunk no existe, generarlo
    if (!chunk) {
        world->generateChunk(chunkPos);
        chunk = world->getChunk(chunkPos);

        // Verificar que se generó correctamente
        if (!chunk) {
            std::cerr << "Error: No se pudo generar el chunk" << std::endl;
            return;
        }
    }

    // Calcular coordenadas locales dentro del chunk
    // CHUNK_SIZE es 8, así que localX y localZ estarán en rango [0, 7]
    int localX = blockPos.x % BlockConfig::CHUNK_SIZE;
    int localZ = blockPos.z % BlockConfig::CHUNK_SIZE;

    // Manejar coordenadas negativas (el operador % en C++ puede dar negativos)
    // Si localX es -3, agregamos 8 para obtener 5 (coordenada válida)
    if (localX < 0) localX += BlockConfig::CHUNK_SIZE;
    if (localZ < 0) localZ += BlockConfig::CHUNK_SIZE;

    // Buscar desde arriba hacia abajo el primer bloque sólido
    // WORLD_HEIGHT es 256, así que buscamos desde Y=255 hasta Y=0
    int surfaceY = BlockConfig::WORLD_HEIGHT - 1;
    for (int y = BlockConfig::WORLD_HEIGHT - 1; y >= 0; y--) {
        const Block& block = chunk->getBlock(localX, y, localZ);
        if (block.esSolido()) {
            surfaceY = y;
            break; // Encontramos el primer bloque sólido desde arriba
        }
    }

    // Posicionar al jugador en la superficie + 1
    // +1 para que el jugador esté ENCIMA del bloque, no dentro de él
    m_posY = static_cast<float>(surfaceY + 1);
}
